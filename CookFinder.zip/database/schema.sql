CREATE DATABASE IF NOT EXISTS cookfinder CHARACTER SET utf8mb4;
USE cookfinder;

DROP TABLE IF EXISTS steps, recipe_ingredients, recipes, ingredients;

CREATE TABLE ingredients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE,
  is_staple BOOLEAN NOT NULL DEFAULT FALSE  -- assumed to be in every kitchen (salt, water...)
);

CREATE TABLE recipes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  image_url VARCHAR(255),                   -- e.g. images/pancakes.jpg or a full URL
  description VARCHAR(255)
);

CREATE TABLE recipe_ingredients (
  recipe_id INT NOT NULL,
  ingredient_id INT NOT NULL,
  amount VARCHAR(50),
  PRIMARY KEY (recipe_id, ingredient_id),
  FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE,
  FOREIGN KEY (ingredient_id) REFERENCES ingredients(id)
);

CREATE TABLE steps (
  id INT AUTO_INCREMENT PRIMARY KEY,
  recipe_id INT NOT NULL,
  step_number INT NOT NULL,
  instruction TEXT NOT NULL,
  FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE CASCADE
);

-- Sample data (add your own below)
INSERT INTO ingredients (name, is_staple) VALUES
 ('salt',1),('water',1),('pepper',1),
 ('egg',0),('flour',0),('milk',0),('sugar',0),('butter',0),
 ('cheese',0),('bread',0),('pasta',0),('tomato',0),('garlic',0),('olive oil',0);

INSERT INTO recipes (id, name, image_url, description) VALUES
 (1,'Pancakes','images/pancakes.jpg','Fluffy breakfast pancakes.'),
 (2,'Scrambled eggs','images/scrambled-eggs.jpg','Soft, creamy eggs in five minutes.'),
 (3,'Tomato garlic pasta','images/tomato-pasta.jpg','Simple weeknight pasta.'),
 (4,'Cheese omelette','images/omelette.jpg','Golden omelette with melted cheese.'),
 (5,'Grilled cheese sandwich','images/grilled-cheese.jpg','Crispy outside, gooey inside.');

INSERT INTO recipe_ingredients (recipe_id, ingredient_id, amount)
SELECT x.r, i.id, x.a FROM (
 SELECT 1 r,'flour' n,'200 g' a UNION ALL SELECT 1,'egg','2' UNION ALL SELECT 1,'milk','300 ml'
 UNION ALL SELECT 1,'sugar','2 tbsp' UNION ALL SELECT 1,'butter','30 g'
 UNION ALL SELECT 2,'egg','3' UNION ALL SELECT 2,'butter','1 tbsp' UNION ALL SELECT 2,'milk','2 tbsp' UNION ALL SELECT 2,'salt','1 pinch'
 UNION ALL SELECT 3,'pasta','200 g' UNION ALL SELECT 3,'tomato','4' UNION ALL SELECT 3,'garlic','2 cloves'
 UNION ALL SELECT 3,'olive oil','2 tbsp' UNION ALL SELECT 3,'salt','to taste'
 UNION ALL SELECT 4,'egg','3' UNION ALL SELECT 4,'cheese','50 g' UNION ALL SELECT 4,'butter','1 tbsp'
 UNION ALL SELECT 5,'bread','2 slices' UNION ALL SELECT 5,'cheese','2 slices' UNION ALL SELECT 5,'butter','1 tbsp'
) x JOIN ingredients i ON i.name = x.n;

INSERT INTO steps (recipe_id, step_number, instruction) VALUES
 (1,1,'Whisk flour, sugar and a pinch of salt in a bowl.'),
 (1,2,'Beat in the eggs and milk until the batter is smooth.'),
 (1,3,'Melt a little butter in a pan over medium heat.'),
 (1,4,'Pour in a ladle of batter and cook until bubbles form, about 2 minutes.'),
 (1,5,'Flip and cook 1 more minute. Repeat with the remaining batter.'),
 (2,1,'Beat the eggs with milk and salt.'),
 (2,2,'Melt the butter in a pan over low heat.'),
 (2,3,'Pour in the eggs and stir gently with a spatula until just set.'),
 (3,1,'Boil the pasta in salted water until al dente.'),
 (3,2,'Heat the olive oil and fry the sliced garlic for 30 seconds.'),
 (3,3,'Add the chopped tomatoes and simmer 10 minutes. Season with salt.'),
 (3,4,'Toss the drained pasta in the sauce and serve.'),
 (4,1,'Beat the eggs with salt and pepper.'),
 (4,2,'Melt the butter in a pan and pour in the eggs.'),
 (4,3,'When almost set, sprinkle the cheese on one half.'),
 (4,4,'Fold the omelette over and cook 1 more minute.'),
 (5,1,'Butter one side of each bread slice.'),
 (5,2,'Place cheese between the slices, buttered sides out.'),
 (5,3,'Fry in a pan over medium heat, 2-3 minutes per side, until golden.');
