# CookFinder
Enter the ingredients you have; CookFinder lists every recipe you can make, with photos and step-by-step instructions.

**Stack:** HTML/CSS/JS frontend (`public/`), Node.js + Express API (`server.js`), MySQL (`database/schema.sql`).

## Run locally (each teammate)
1. Install Node.js 18+ and MySQL.
2. `npm install`
3. Copy `.env.example` to `.env` and fill in your MySQL login.
4. Create the database: `mysql -u root -p < database/schema.sql`
5. `npm start`, then open http://localhost:3000

## Adding recipes
Add rows to `ingredients`, `recipes`, `recipe_ingredients`, `steps` in `database/schema.sql`, put photos in `public/images/`, and re-run step 4. Keep ingredient names lowercase.

## Teamwork on GitHub
- One person creates the repo and adds the others under Settings > Collaborators.
- Never commit `.env`. Each person has their own local database; share data changes through `schema.sql`.
- Work on branches (`git checkout -b feature/search-ui`), push, open a Pull Request, and let a teammate review before merging into `main`.
- `git pull` before you start working.
