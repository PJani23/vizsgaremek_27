require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');

const app = express();
app.use(express.json());
app.use(express.static('public'));

const db = mysql.createPool({
  host: process.env.DB_HOST, user: process.env.DB_USER,
  password: process.env.DB_PASSWORD, database: process.env.DB_NAME
});

// All known ingredient names (for autocomplete)
app.get('/api/ingredients', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT name FROM ingredients WHERE is_staple = 0 ORDER BY name');
    res.json(rows.map(r => r.name));
  } catch (e) { console.error(e); res.status(500).json({ error: 'Database error' }); }
});

// Recipes that can be made using ONLY the given ingredients (staples are assumed)
app.post('/api/recipes/search', async (req, res) => {
  try {
    const list = (req.body.ingredients || []).map(s => String(s).trim().toLowerCase()).filter(Boolean);
    if (!list.length) return res.json([]);
    const [recipes] = await db.query(
      `SELECT r.id, r.name, r.image_url, r.description
       FROM recipes r
       JOIN recipe_ingredients ri ON ri.recipe_id = r.id
       JOIN ingredients i ON i.id = ri.ingredient_id
       GROUP BY r.id
       HAVING SUM(i.is_staple = 0 AND i.name NOT IN (?)) = 0 AND SUM(i.is_staple = 0) > 0
       ORDER BY r.name`, [list]);
    for (const r of recipes) {
      [r.ingredients] = await db.query(
        `SELECT i.name, ri.amount FROM recipe_ingredients ri
         JOIN ingredients i ON i.id = ri.ingredient_id WHERE ri.recipe_id = ?`, [r.id]);
      [r.steps] = await db.query(
        'SELECT instruction FROM steps WHERE recipe_id = ? ORDER BY step_number', [r.id]);
    }
    res.json(recipes);
  } catch (e) { console.error(e); res.status(500).json({ error: 'Database error' }); }
});

app.listen(process.env.PORT || 3000, () =>
  console.log(`CookFinder running on http://localhost:${process.env.PORT || 3000}`));
