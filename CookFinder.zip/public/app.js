const input = document.getElementById('ingredient-input');
const chips = document.getElementById('chips');
const results = document.getElementById('results');
const statusEl = document.getElementById('status');
let ingredients = [];

fetch('/api/ingredients').then(r => r.json()).then(names => {
  document.getElementById('ingredient-list').innerHTML = names.map(n => `<option value="${n}">`).join('');
}).catch(() => {});

function addIngredient() {
  const value = input.value.trim().toLowerCase();
  input.value = '';
  if (value && !ingredients.includes(value)) { ingredients.push(value); update(); }
  input.focus();
}

function removeIngredient(name) { ingredients = ingredients.filter(i => i !== name); update(); }

function update() {
  chips.innerHTML = '';
  ingredients.forEach(name => {
    const li = document.createElement('li');
    li.textContent = name;
    const b = document.createElement('button');
    b.textContent = '×';
    b.setAttribute('aria-label', 'Remove ' + name);
    b.onclick = () => removeIngredient(name);
    li.appendChild(b);
    chips.appendChild(li);
  });
  search();
}

async function search() {
  if (!ingredients.length) { results.innerHTML = ''; statusEl.textContent = 'Add your first ingredient to get started.'; return; }
  try {
    const res = await fetch('/api/recipes/search', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ingredients })
    });
    if (!res.ok) throw new Error();
    render(await res.json());
  } catch { statusEl.textContent = 'Could not reach the server. Check that it is running.'; }
}

const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function render(recipes) {
  statusEl.textContent = recipes.length
    ? `You can make ${recipes.length} recipe${recipes.length > 1 ? 's' : ''}.`
    : 'No recipe matches these ingredients yet. Try adding more.';
  results.innerHTML = recipes.map(r => `
    <article class="recipe">
      <img class="photo" src="${esc(r.image_url)}" alt="${esc(r.name)}" onerror="this.style.visibility='hidden'">
      <div class="body">
        <h2>${esc(r.name)}</h2>
        <p class="desc">${esc(r.description)}</p>
        <h3>Ingredients</h3>
        <ul>${r.ingredients.map(i => `<li>${esc(i.name)} <span>${esc(i.amount)}</span></li>`).join('')}</ul>
        <h3>Instructions</h3>
        <ol>${r.steps.map(s => `<li>${esc(s.instruction)}</li>`).join('')}</ol>
      </div>
    </article>`).join('');
}

document.getElementById('add-btn').onclick = addIngredient;
input.addEventListener('keydown', e => { if (e.key === 'Enter') addIngredient(); });
update();
